%% Objective Function
function z=Sphere(x)
    z=sum(x.^2);
end